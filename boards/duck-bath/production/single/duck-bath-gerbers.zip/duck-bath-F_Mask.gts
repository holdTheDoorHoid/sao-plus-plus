G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.6*
G04 #@! TF.CreationDate,2026-11-12T02:45:58-05:00*
G04 #@! TF.ProjectId,duck-bath,6475636b-2d62-4617-9468-2e6b69636164,A*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.6) date 2026-11-12 02:45:58*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
