G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.8*
G04 #@! TF.CreationDate,2026-11-11T22:42:31-05:00*
G04 #@! TF.ProjectId,nsec-diamond,6e736563-2d64-4696-916d-6f6e642e6b69,A*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.8) date 2026-11-11 22:42:31*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
