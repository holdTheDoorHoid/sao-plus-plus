G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.8*
G04 #@! TF.CreationDate,2026-11-11T22:24:17-05:00*
G04 #@! TF.ProjectId,yo-dawg,796f2d64-6177-4672-9e6b-696361645f70,A*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.8) date 2026-11-11 22:24:17*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.050000X0.500000X-0.500000X0.500000X0.500000X-0.500000X0.500000X-0.500000X-0.500000X0*%
%ADD11C,1.100000*%
G04 APERTURE END LIST*
D10*
X8730000Y-18000000D03*
D11*
X10000000Y-18000000D03*
X11270000Y-18000000D03*
D10*
X28730000Y-18000000D03*
D11*
X30000000Y-18000000D03*
X31270000Y-18000000D03*
D10*
X8730000Y-38000000D03*
D11*
X10000000Y-38000000D03*
X11270000Y-38000000D03*
M02*
